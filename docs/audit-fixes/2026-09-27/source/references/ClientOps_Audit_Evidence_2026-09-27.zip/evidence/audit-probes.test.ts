import { describe, it, expect, vi, beforeEach } from 'vitest';
const m = vi.hoisted(() => {
 const db = { query: vi.fn() };
 return { db, query: vi.fn(), queryOne: vi.fn(), any: vi.fn(),
 transaction: vi.fn(async (work: (db: typeof db) => unknown) => work(db)) };
});
vi.mock('@tanstack/react-start', () => ({ createServerFn: () => {
 const chain = { validator: () => chain, handler: (fn: unknown) => fn }; return chain;
}}));
vi.mock('@/server/auth/authorization.server', () => ({ requireAnyCapability: m.any }));
vi.mock('@/server/db/neon.server', () => ({ query:m.query, queryOne:m.queryOne, transaction:m.transaction }));
import { searchWorkspace } from '@/server-functions/search';
import { ROLE_GRANTS, evaluateAuthorization } from '@/lib/admin/policy';
import { decideApproval } from '@/server/repositories/approvals';
import { updateQuote } from '@/server/repositories/quotes';
import { updateJobSheetXeroReference } from '@/server/repositories/job-sheets';
import { escapeCsvValue } from '@/lib/csv';
import { formatDateTime } from '@/lib/format';
import { parseImportCsv } from '@/lib/csv-import';

// Characterization probes: passing means the audited undesirable behavior exists.
// Database functions are mocked. These are not production or real-Postgres tests.
describe('audit 2026-09-27 characterization probes', () => {
 beforeEach(() => { vi.clearAllMocks(); m.query.mockResolvedValue([]); });
 it('accounting lacks leads.view, but the search boundary returns lead results', async () => {
  expect(ROLE_GRANTS.accounting.has('leads.view')).toBe(false);
  m.any.mockImplementation(async (caps:string[]) => {
   if (!caps.some(c => ROLE_GRANTS.accounting.has(c as never))) throw Error('forbidden');
  });
  m.query.mockResolvedValue([{id:'synthetic-lead', type:'Lead',title:'SYNTHETIC Restricted Lead',subtitle:'Synthetic contact',href:'/leads/synthetic-lead',matched_on:'lead',type_order:3}]);
  const result = await (searchWorkspace as any)({data:{query:'SYNTHETIC'}});
  expect(result[0].type).toBe('Lead');
  expect(m.query.mock.calls[0][0]).toContain('from tasks t');
  expect(m.any.mock.calls[0][0]).not.toContain('tasks.view');
 });
 it('manager approval grant does not grant the issuance required by the approval queue', () => {
  const actor:any = {profileId:'m',role:'manager',status:'active',departmentId:null,managedDepartmentIds:[],managedTeamIds:[],directReportIds:[]};
  const target = {resourceType:'quote',resourceId:'q',ownerProfileId:'m'};
  expect(evaluateAuthorization({actor,target,capability:'quotes.approve'}).allowed).toBe(true);
  expect(evaluateAuthorization({actor,target,capability:'quotes.issue'}).allowed).toBe(false);
 });
 it('a terminal approval can be rewritten because its UPDATE has no state predicate', async () => {
  m.db.query.mockImplementation(async (sql:string, values:unknown[]) => {
   if(sql.includes('update human_approvals')) return {rows:[{id:'a',status:values[1],agent_run_id:null,approval_type:'message_send'}]};
   return {rows:[]};
  });
  await decideApproval({id:'a',decision:'approved',actorId:'one'});
  const result = await decideApproval({id:'a',decision:'rejected',actorId:'two'});
  expect(result.status).toBe('rejected');
  const sql = m.db.query.mock.calls.find(c=>c[0].includes('update human_approvals'))![0];
  expect(sql.replace(/\s+/g,' ')).toContain('where id = $1 returning');
 });
 it('the quote update repository allows a commercial edit without a status guard', async () => {
  m.queryOne.mockResolvedValue({id:'q',status:'accepted',total_value:999});
  const result = await updateQuote('q',{total_value:999});
  expect(result.status).toBe('accepted');
  const sql = m.queryOne.mock.calls[0][0].replace(/\s+/g,' ');
  expect(sql).toContain('update quotes');
  expect(sql).not.toMatch(/where.*status/i);
 });
 it('Xero status is set by any supplied note as well as invoice fields', async () => {
  m.queryOne.mockResolvedValue({id:'p'});
  await updateJobSheetXeroReference({portion_id:'p',xero_notes:'Need invoice later'});
  const [sql,args] = m.queryOne.mock.calls[0];
  expect(args.slice(0,4)).toEqual([null,null,null,'Need invoice later']);
  expect(sql.replace(/\s+/g,' ')).toContain("or $4 is not null then 'entered_in_xero'");
 });
 it('a valid quoted multiline CSV field is incorrectly split into two rows', () => {
  expect(parseImportCsv('company_name,enquiry_text\r\nAcme,"First line\nSecond line"').length).toBe(2);
 });
 it('CSV formula-like text is not neutralized', () => {
  expect(escapeCsvValue('=1+1')).toBe('=1+1');
 });
 it('Hong Kong midnight timestamp is displayed as the previous date without timezone', () => {
  expect(formatDateTime('2026-09-26T16:30:00Z')).toBe('26 Sept 2026, 16:30');
 });
});
